from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
import os

os.environ["OPENAI_API_KEY"] = (
    "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"  # 🔒 Replace with your key
)


model = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)

chat_history = [SystemMessage(content="You are a helpful AI assistant")]

while True:
    user_input = input("You: ")
    chat_history.append(HumanMessage(content=user_input))

    if user_input.lower() == "exit":
        break

    # Invoke model
    result = model.invoke(chat_history)

    # Append assistant response
    chat_history.append(AIMessage(content=result.content))

    # Print AI response
    print("AI:", result.content)

    # ✅ Print token usage
    usage = result.response_metadata.get("token_usage", {})
    input_tokens = usage.get("prompt_tokens", 0)
    output_tokens = usage.get("completion_tokens", 0)
    total_tokens = usage.get("total_tokens", 0)

    print(
        f"Tokens used -> Input: {input_tokens}, Output: {output_tokens}, Total: {total_tokens}"
    )

print(chat_history)
