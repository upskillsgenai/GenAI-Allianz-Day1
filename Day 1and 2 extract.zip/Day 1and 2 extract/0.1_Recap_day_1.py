# objective : make make a app which accept user input call gpt model

# import packages
from langchain_openai import ChatOpenAI

# set the key

# define  the model
model = ChatOpenAI(
    api_key="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",
    model="gpt-4o-mini",
    temperature=0.7,
)

# call the model
print("Welcome in Session , Please ask you questions . Type exit to quit \n")

# loop until user have a query

while True:
    user_input = input("You :")
    if user_input == "exit":
        print("Exiting chat ... good bye !! ")
        break
    result = model.invoke(user_input)
    print("AI :", result.content)
