from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
import os

os.environ["OPENAI_API_KEY"] = (
    "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"  # 🔒 Replace with your key
)


model = ChatOpenAI()

chat_history = [SystemMessage(content="You are a helpful AI assistant")]

while True:
    user_input = input("You: ")
    chat_history.append(HumanMessage(content=user_input))
    if user_input == "exit":
        break
    result = model.invoke(chat_history)
    chat_history.append(AIMessage(content=result.content))
    print("AI: ", result.content)

print(chat_history)
